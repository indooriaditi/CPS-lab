"""
CSCI-603: Graphs
Author: RIT CS, Aditi Indoori

An implementation of a graph data structure as an adjacency list.

Code taken from the online textbook and modified:

http://interactivepython.org/runestone/static/pythonds/Graphs/Implementation.html
"""
from typing import Hashable

from vertex import Vertex


class Graph:
    """
    A graph implemented as an adjacency list of vertices.

    :slot: vertList (dict):  A dictionary that maps a vertex key to a Vertex
        object
    :slot: _size (int):  The total number of vertices in the graph
    """
    __slots__ = '_vertDict', '_size'
    _vertDict: dict[Hashable, Vertex]
    _size: int

    def __init__(self):
        """
        Initialize the graph
        :return: None
        """
        self._vertDict = {}
        self._size = 0

    def add_vertex(self, name: Hashable, vertex) -> Vertex:
        """
        Add a new vertex to the graph.
        :param name: The identifier for the vertex (typically a string)
        :return: Vertex
        """
        # count this vertex if not already present
        if self.get_vertex(name) == None:
            self._size += 1
            self._vertDict[name] = vertex
        return vertex

    def get_vertex(self, name: Hashable) -> Vertex:
        """
        Retrieve the vertex from the graph.
        :param name: The vertex name
        :return: Vertex if it is present, otherwise None
        """
        if name in self._vertDict:
            return self._vertDict[name]
        else:
            return None

    def __contains__(self, name: Hashable) -> bool:
        """
        Returns whether the vertex is in the graph or not.  This allows the
        user to do:
            key in graph
        :param key: The vertex identifier
        :return: True if the vertex is present, and False if not
        """
        return name in self._vertDict

    def add_edge(self, src: Hashable, dest: Hashable):
        """
        Add a new directed edge from a source to a destination.
        :param src: The source vertex identifier
        :param dest: The destination vertex identifier
        :return: None
        """
        if src not in self._vertDict:
            self.add_vertex(src)
        if dest not in self._vertDict:
            self.add_vertex(dest)
        self._vertDict[src].add_neighbor(self._vertDict[dest])

    def get_vertices(self):
        """
        Return the collection of vertex identifiers in the graph.
        :return: A list of vertex identifiers
        """
        return self._vertDict.keys()

    def __iter__(self):
        """
        Return an iterator over the vertices in the graph.  This allows the
        user to do:

            for vertex in graph:
                ...

        :return: A list iterator over Vertex objects
        """
        return iter(self._vertDict.values())
