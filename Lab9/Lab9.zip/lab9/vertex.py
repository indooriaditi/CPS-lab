"""
CSCI-603: Vertex
Author: RIT CS, Aditi Indoori

An implementation of a vertex as part of a graph.

Code taken from the online textbook and modified:

http://interactivepython.org/runestone/static/pythonds/Graphs/Implementation.html
"""

from typing import Hashable


class Vertex:
    """
    An individual vertex in the graph.

    :slots: name:  The identifier for this vertex (user defined, typically
        a string)
    :slots: iscow: checks whether the vertex is a cow or not
    :slots: xcoord: xcoord of the vertex
    :slots: ycoord: ycoord of the vertex
    :slots: radius: radius of the paintball
    :slots: neighbors:  A dictionary of adjacent neighbors, where the key is
        the neighbor (Vertex), and the value is the edge cost (int)
    """

    __slots__ = '_iscow', '_name', '_xcoord', '_ycoord', '_paintball_radius', '_neighbors'
    _iscow: bool
    _name: str
    _xcoord: int
    _ycoord: int
    _paintball_radius: int
    _neighbors: dict['Vertex']

    def __init__(self, iscow: bool, name: str, xcoord: int, ycoord: int, paintball_radius: int = None):
        """
        Initialize a vertex
        :param iscow: bool that checks whether the vertex is a cow or not
        :param name: The identifier for this vertex
        :param xcoord: xcoord of the vertex
        :param ycoord: ycoord of the vertex
        :param paintball_radius: paintball's radius, default None
        :return: None
        """
        self._iscow = iscow
        self._name = name
        self._xcoord = xcoord
        self._ycoord = ycoord
        self._paintball_radius = paintball_radius
        self._neighbors = []

    def add_neighbor(self, neighbor: 'Vertex') -> None:
        """
        Connect this vertex to a neighbor.
        :param neighbor: The neighbor vertex
        :return: None
        """
        self._neighbors.append(neighbor)

    def __str__(self) -> str:
        """
        Return a string representation of the vertex and its direct neighbors:

            vertex-id neighbors [neighbor-1-id, neighbor-2-id, ...]

        :return: The string
        """
        return str(self._name) + ' neighbors: ' + str([str(x._name) for x in self._neighbors])

    def get_neighbors(self):
        """
        Get the neighbor vertices.
        :return: A list of Vertex neighbors
        """
        return self._neighbors

    def iscow(self):
        """
        check whether vertex is cow or not.
        :return: bool
        """
        return self._iscow

    def get_name(self) -> str:
        """
        Get the vertex name
        :return: the name
        """
        return self._name

    def get_xcoord(self) -> int:
        """
        Get the vertex xcoordinate
        :return: the vertex xcoordinate
        """
        return self._xcoord

    def get_ycoord(self) -> int:
        """
        Get the vertex ycoordinate
        :return: the vertex ycoordinate
        """
        return self._ycoord

    def get_paintball_radius(self) -> int:
        """
        Get the paintball radius
        :return: the paintball radius
        """
        return self._paintball_radius
