"""
CSCI-603 Lab 9: Graphs
Author: Aditi Indoori

An implementation of a graph data structure representing a field with cows and paintballs.

"""

import sys
import os
import math
from graph import Graph
from vertex import Vertex


class Holicow:
    __slots__ = 'file_name', 'cows', 'cow_count', 'paintballs', 'paintball_count', 'max_cows_painted', \
                'cow_color_tracker', 'best_cow_color_tracker', 'best_color'

    def __init__(self, file_name):
        """
        Initialize the filename, cow_count, paintball_count.
        """
        self.file_name = file_name
        self.cow_count = 0
        self.cows = []
        self.paintball_count = 0
        self.paintballs = []
        self.cow_color_tracker = {}
        self.best_cow_color_tracker = {}
        self.best_color = None
        self.max_cows_painted = 0

    def create_graph(self, graph):
        """
        Create a graph by reading information from the file.
        :param: graph (Graph): The graph object to which vertices and edges will be added.
        :returns: tuple: A tuple containing the number of vertices, cow count, and paintball count.
        """
        with open(self.file_name) as f:
            for line in f:
                l = line.strip().split()
                if l[0] == 'cow':
                    cow = Vertex(True, l[1], int(l[2]), int(l[3]))
                    self.cow_count += 1
                    self.cows.append(cow.get_name())
                    graph.add_vertex(cow.get_name(), cow)
                else:
                    paintball = Vertex(False, l[1], int(l[2]), int(l[3]), int(l[4]))
                    self.paintball_count += 1
                    self.paintballs.append(paintball.get_name())
                    graph.add_vertex(paintball.get_name(), paintball)
        g = graph._vertDict
        for i in g.keys():
            for j in g.keys():
                # Compare a paintball and cow or 2 paintballs
                if not g[i].iscow() and g[j].iscow() or not g[i].iscow() and not g[j].iscow():
                    euclidean_dist = math.dist([g[i].get_xcoord(), g[i].get_ycoord()], [
                        g[j].get_xcoord(), g[j].get_ycoord()])
                    if euclidean_dist <= float(g[i].get_paintball_radius()) and euclidean_dist > 0:
                        graph.add_edge(g[i].get_name(), g[j].get_name())
        return graph._size, self.cow_count, self.paintball_count

    def paint_neighbors(self, visited, vertex):
        """
        Recursively paint the neighbors of the given vertex.
        :param: visited (set): A set of visited vertices.
        :param: vertex (Vertex): The vertex whose neighbors need to be painted.
        """
        for neighbor in vertex.get_neighbors():
            if neighbor.get_name() not in visited:
                if neighbor.iscow():
                    print("\t" + neighbor.get_name() +
                          " is painted " + vertex.get_name() + "!")
                    if neighbor.get_name() not in self.cow_color_tracker:
                        self.cow_color_tracker[neighbor.get_name()] = [
                            vertex.get_name()]
                    else:
                        self.cow_color_tracker[neighbor.get_name()].append(
                            vertex.get_name())
                else:
                    print("\t" + neighbor.get_name() + " paint ball is triggered by " +
                          vertex.get_name() + " paint ball")
                    visited.add(neighbor.get_name())
                    # print(visited)
                    self.paint_neighbors(visited, neighbor)

    def simulation(self, graph):
        """
        Simulate the painting process on the graph.
        :param: graph (Graph): The graph object representing the field.
        """
        for vertex in graph:
            visited = set()
            if not vertex.iscow() and vertex.get_name() not in visited:
                visited.add(vertex.get_name())
                print("Triggering " + vertex.get_name() + " paint ball...")
                self.cow_color_tracker = {}
                self.paint_neighbors(visited, vertex)
                if len(self.cow_color_tracker) > len(self.best_cow_color_tracker):
                    self.best_cow_color_tracker = self.cow_color_tracker
                    self.best_color = vertex.get_name()


def run():
    """
    Run the Holicow simulation.
    """
    if len(sys.argv) != 2:
        print("Usage: python3 holicow.py {filename}")
        sys.exit()

    filename = 'Tests/' + sys.argv[1]

    if not os.path.exists(filename):
        print(f"File not found: {sys.argv[1]}")
        sys.exit()

    hc = Holicow(filename)
    graph = Graph()
    vertices, cows, paintballs = hc.create_graph(graph)
    print('Field of Dreams')
    print('Number of vertices: ' + str(vertices) + ',' + ' cows: ' +
          str(cows) + ',' + ' paintballs: ' + str(paintballs))
    print('-----------------------------------------------------')

    for vertex in graph:
        print(vertex)

    print('\nBeginning simulation...')

    hc.simulation(graph)

    print("\nResults:")
    for values in hc.best_cow_color_tracker.values():
        hc.max_cows_painted += len(values)

    if hc.max_cows_painted > 0:
        print(f"Triggering the {hc.best_color} paint ball is the "
              f"best choice with {hc.max_cows_painted} total paint on the cows:")

        for cow in hc.cows:
            colors = hc.best_cow_color_tracker.get(cow, set())
            if colors:
                print(f"\t{cow}'s colors: {set(colors)}")
            else:
                print(f"\t{cow}'s colors: {{}}")
    else:
        print("No cows were painted by any starting paint ball!")


def main():
    run()


if __name__ == '__main__':
    main()
