"""
CSCI-603 Lab 2: Ciphers

A program that encodes/decodes a message by applying a set of transformation
operations.

The transformation operations are:
    shift - Si[,k] changes letter at index i by moving it k letters fwd
            in the alphabet.
            A negative index for k shifts the letter backward in the alphabet.
    rotate - R[k] rotates the string k positions to the right.
            A negative index for k rotates the string to the left.
    duplicate - Di[,k] follows character at index i with k copies of itself.
    trade - Ti,j swap the places of the i-th and j-th characters.
    affine - Aa,b applies the affine cipher algorithm y = (ax + b) mod 26
            using a and b as keys.

All indices numbers (the subscript parameters) are 0-based.

author: ADITI INDOORI
"""


def shift(message: str, char_index: int, shift_count: int) -> str:
    """
    Shifts a character in the message by a given number of positions
    in the alphabet.
    :args:
        message (str): The input message.
        char_index (int): Index of the character to be shifted.
        shift_count (int): Number of positions to shift the character.
    :returns:
        str: The encrypted message with the character shifted.
    """
    move = ord(message[char_index]) + shift_count
    if move > ord('Z'):
        move = (move % ord('Z')) + ord('A') - 1
    elif move < ord('A'):
        move = 1 + ord('Z') - (ord('A') % move)
    return message[:char_index] + chr(move) + message[char_index + 1:]


def rotate(message: str, rotation_count: int) -> str:
    """
    Rotates the message by a given number of positions to the right
    (or left if rotation_count is negative).
    :args:
        message (str): The input message.
        rotation_count (int): Number of positions to rotate the message.
    :returns:
        str: The rotated message.
    """
    while rotation_count > 0:
        message = message[-1] + message[:-1]
        rotation_count -= 1
    while rotation_count < 0:
        message = message[1:] + message[0]
        rotation_count += 1
    return message


def duplicate_encrypt(message: str, char_index: int, duplicate_count: int) -> str:
    """
    Duplicates a character in the message.
    :args:
        message (str): The input message.
        char_index (int): Index of the character to be duplicated.
        duplicate_count (int): Number of copies to insert after the character.
    :returns:
        str: The modified message with the character duplicated.
    """
    while duplicate_count > 0:
        message = message[:char_index + 1] + message[char_index] \
                  + message[char_index + 1:]
        char_index += 1
        duplicate_count -= 1
    return message


def duplicate_decrypt(message: str, char_index: int, duplicate_count: int) -> str:
    """
    Removes duplicated characters from the message.
    :args:
        message (str): The input message.
        char_index (int): Index of the character with duplicates.
        duplicate_count (int): Number of duplicates to remove.
    :returns:
        str: The modified message with duplicates removed.
    """
    message = message[:char_index + 1] + message[char_index + duplicate_count + 1:]
    return message


def trade(message: str, first_char_index: int, second_char_index: int) -> str:
    """
    Swaps the positions of two characters in the message.
    :args:
        message (str): The input message.
        first_char_index (int): Index of the first character to swap.
        second_char_index (int): Index of the second character to swap.
    :returns:
        str: The modified message with characters swapped.
    """
    return message[:first_char_index] + message[second_char_index] \
           + message[first_char_index + 1:second_char_index] \
           + message[first_char_index] + message[second_char_index + 1:]


def affine_encrypt(message: str, a_key: int, b_key: int) -> str:
    """
    Encrypts the message using the Affine cipher algorithm.
    :args:
        message (str): The input message.
        a_key (int): The 'a' key for the Affine cipher.
        b_key (int): The 'b' key for the Affine cipher.
    :returns:
        str: The encrypted message.
    """
    new_message = ''
    for i in message:
        new_message += chr(((a_key * (ord(i) - 65) + b_key) % 26) + 65)
    return new_message


def affine_decrypt(message: str, a_key: int, b_key: int) -> str:
    """
    Decrypts the message encrypted using the Affine cipher algorithm.
    :args:
        message (str): The input message.
        a_key (int): The 'a' key for the Affine cipher.
        b_key (int): The 'b' key for the Affine cipher.
    :returns:
        str: The decrypted message.
    """
    new_message = ''
    for i in message:
        for j in range(26):
            if ord(i) - 65 == ((a_key * j) + b_key) % 26:
                new_message += chr(j + 65)
    return new_message


def encrypt(message: str, transformation: str) -> str:
    """
    Encrypts the message by applying a series of transformation operations.
    :args:
        message (str): The input message to be encrypted.
        transformation (str): The transformation operations to apply.
    :returns:
        str: The encrypted message.
    """
    transform_ops = transformation.split(';')
    for i in range(len(transform_ops)):
        transform_ops[i] = transform_ops[i].split(',')

        # affine
        if transform_ops[i][0][0] == 'A':
            message = affine_encrypt(message, int(transform_ops[i][0][1]),
                                     int(transform_ops[i][1]))

        # trade
        if transform_ops[i][0][0] == 'T':
            message = trade(message, int(transform_ops[i][0][1]),
                            int(transform_ops[i][1]))

        # rotate
        if transform_ops[i][0][0] == 'R':
            if len(transform_ops[i][0]) > 1:
                rotation_count = int(transform_ops[i][0][1:])
            else:
                rotation_count = 1
            message = rotate(message, rotation_count)

        # shift
        if transform_ops[i][0][0] == 'S':
            index = int(transform_ops[i][0][1:])
            if len(transform_ops[i]) == 1:
                shift_count = 1
            elif len(transform_ops[i]) > 1:
                shift_count = int(transform_ops[i][1])
            message = shift(message, index, shift_count)

        # duplicate
        if transform_ops[i][0][0] == 'D':
            index = int(transform_ops[i][0][1:])
            if len(transform_ops[i]) == 1:
                duplicate_count = 1
            elif len(transform_ops[i]) > 1:
                duplicate_count = int(transform_ops[i][1])
            message = duplicate_encrypt(message, index, duplicate_count)

    return message


def decrypt(message: str, transformation: str) -> str:
    """
    Decrypts the message by applying a series of transformation operations.
    :args:
        message (str): The input message to be decrypted.
        transformation (str): The transformation operations to apply
                            for decryption.
    :return:
        str: The decrypted message.
    """
    transform_ops = transformation.split(';')
    for i in range(len(transform_ops) - 1, -1, -1):
        transform_ops[i] = transform_ops[i].split(',')

        # affine
        if transform_ops[i][0][0] == 'A':
            message = affine_decrypt(message, int(transform_ops[i][0][1]),
                                     int(transform_ops[i][1]))

        # trade
        if transform_ops[i][0][0] == 'T':
            message = trade(message, int(transform_ops[i][0][1]),
                            int(transform_ops[i][1]))

        # rotate
        if transform_ops[i][0][0] == 'R':
            if len(transform_ops[i][0]) > 1:
                rotation_count = int(transform_ops[i][0][1:])
            else:
                rotation_count = 1
            message = rotate(message, -rotation_count)

        # shift
        if transform_ops[i][0][0] == 'S':
            index = int(transform_ops[i][0][1:])
            if len(transform_ops[i]) == 1:
                shift_count = 1
            elif len(transform_ops[i]) > 1:
                shift_count = int(transform_ops[i][1])
            message = shift(message, index, -shift_count)

        # duplicate
        if transform_ops[i][0][0] == 'D':
            index = int(transform_ops[i][0][1:])
            if len(transform_ops[i]) == 1:
                duplicate_count = 1
            elif len(transform_ops[i]) > 1:
                duplicate_count = int(transform_ops[i][1])
            message = duplicate_decrypt(message, index, duplicate_count)

    return message


def main() -> None:
    """
    The main loop responsible for getting the input details from the user
    and printing in the standard output the results
    of encrypting or decrypting the message applying the transformations
    :return: None
    """
    print('Welcome to Ciphers!')
    option = 'temp'
    while option != 'Q':
        option = input('What do you want to do: (E)ncrypt, (D)ecrypt, (Q)uit? ')
        if option == 'E':
            message_to_encrypt = input('Enter the message: ')
            encryption_op_string = input('Enter the encrypting '
                                         'transformation operations: ')
            print('Generating output...')
            print(encrypt(message_to_encrypt, encryption_op_string))
        if option == 'D':
            message_to_decrypt = input('Enter the message: ')
            decryption_op_string = input('Enter the decrypting '
                                         'transformation operations: ')
            print('Generating output...')
            print(decrypt(message_to_decrypt, decryption_op_string))
        if option == 'Q':
            print('Goodbye!')


if __name__ == '__main__':
    main()
