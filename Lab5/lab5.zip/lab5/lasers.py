"""
CSCI-603 Lab 5: lasers

Implementing a lasers program that 
solves any rectangular laser problem.

author: ADITI INDOORI
"""

from dataclasses import dataclass
import sys
import sort


@dataclass
class Lasers:
    """
    A representation of rectangular laser puzzle.
    """
    puzzle: list
    puzzle_len_i: int
    puzzle_len_j: int
    solutions: dict
    num_lasers: int
    total_sum: int
    file_name: str

    def __init__(self):
        """
        Initializes a new instance of the problem.
        """
        if len(sys.argv) > 2:
            print("Usage: python3 lasers.py filename")
            sys.exit()
        else:
            self.file_name = sys.argv[1]
        self.puzzle = self.read_file(self.file_name)
        self.puzzle_len_i = len(self.puzzle)
        self.puzzle_len_j = len(self.puzzle[0])
        self.solutions = dict()

    def read_file(self, file_name: str) -> list:
        """
        Reads puzzle from a file and stores it as 
        a list of lists.
        :args:
            file_name (str): name of the file.
        :returns:
            list: list of lists representing the puzzle.
        """
        l = list()
        with open(file_name) as f:
            for line in f:
                l.append(list(map(int, line.strip().split())))
        return l

    def display_puzzle(self) -> None:
        """
        Displays the puzzle.
        """
        print("Loaded: " + self.file_name)
        for i in range(self.puzzle_len_i):
            for j in range(self.puzzle_len_j):
                print(self.puzzle[i][j], end=" ")
            print()

    def solve(self) -> dict:
        """
        Finds the optimal solution for each laser 
        and stores it in a dictionary.
        :returns:
            dict: stores the coordinates,direction as key and sum as value.
        """
        for i in range(self.puzzle_len_i):
            for j in range(self.puzzle_len_j):
                if (i == 0 and j == 0) or (i == 0 and j == self.puzzle_len_j - 1) or (
                        i == self.puzzle_len_i - 1 and j == 0) or (
                        i == self.puzzle_len_i - 1 and j == self.puzzle_len_j - 1):
                    continue

                # top - facing south
                elif i == 0 and (j != 0 and j != self.puzzle_len_j - 1):
                    self.solutions[(i, j), 'S'] = sum(
                        [self.puzzle[i][j - 1], self.puzzle[i][j + 1], self.puzzle[i + 1][j]])

                # left - facing east
                elif j == 0 and (i != 0 and i != self.puzzle_len_i - 1):
                    self.solutions[(i, j), 'E'] = sum(
                        [self.puzzle[i - 1][j], self.puzzle[i + 1][j], self.puzzle[i][j + 1]])

                # bottom - facing north
                elif i == self.puzzle_len_i - 1 and (j != 0 and j != self.puzzle_len_j - 1):
                    self.solutions[(i, j), 'N'] = sum(
                        [self.puzzle[i][j - 1], self.puzzle[i][j + 1], self.puzzle[i - 1][j]])

                # right - facing west
                elif j == self.puzzle_len_j - 1 and (i != 0 and i != self.puzzle_len_i - 1):
                    self.solutions[(i, j), 'W'] = sum(
                        [self.puzzle[i - 1][j], self.puzzle[i + 1][j], self.puzzle[i][j - 1]])

                else:
                    south = [self.puzzle[i][j - 1], self.puzzle[i]
                             [j + 1], self.puzzle[i + 1][j]]
                    east = [self.puzzle[i - 1][j], self.puzzle[i + 1]
                            [j], self.puzzle[i][j + 1]]
                    north = [self.puzzle[i][j - 1], self.puzzle[i]
                             [j + 1], self.puzzle[i - 1][j]]
                    west = [self.puzzle[i - 1][j], self.puzzle[i + 1]
                            [j], self.puzzle[i][j - 1]]

                    all_sum = [sum(south), sum(east), sum(north), sum(west)]

                    if all_sum.index(max(all_sum)) == 0:
                        direction = 'S'
                    elif all_sum.index(max(all_sum)) == 1:
                        direction = 'E'
                    elif all_sum.index(max(all_sum)) == 2:
                        direction = 'N'
                    elif all_sum.index(max(all_sum)) == 3:
                        direction = 'W'

                    self.solutions[(i, j), direction] = max(all_sum)

        self.solutions = sort.selection(list(self.solutions.items()))
        return self.solutions

    def get_input(self) -> None:
        """
        Gets the input for the number of lasers
        and displays the optimal placement and total sum.
        """
        sum_lst = list()
        self.num_lasers = int(input("Enter number of lasers: "))
        if self.num_lasers > len(self.solutions):
            print("Too many lasers to place!")
            sys.exit()
        elif self.num_lasers == 0:
            print("Total: 0")
        else:
            print("Optimal placement:")
            for i in range(self.num_lasers):
                sum_lst.append(self.solutions[i][1])
                print("loc: " + str(self.solutions[i][0][0]) + " , facing: " + str(
                    self.solutions[i][0][1]) + ", sum: " + str(self.solutions[i][1]))
            print("Total Sum: " + str(sum(sum_lst)))

    def main(self) -> None:
        """
        The main method that starts the lasers puzzle problem.
        """
        self.display_puzzle()
        self.solve()
        self.get_input()


if __name__ == "__main__":
    """
    Creating an instance of the class
    and calling the main method.
    """
    lasers_obj = Lasers()
    lasers_obj.main()
