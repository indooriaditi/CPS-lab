"""
CSCI-603 Lab 5: lasers

This is an implementation of Selection Sort Algorithm
that orders the sum in descending order.

author: ADITI INDOORI, MARIA JOSE CEPEDA GARCIA
"""

def findmax(data: dict, mark: int) -> int:
    """ 
    Find the maximum value
    :args:
        data (dict): dictionary of coordinates,direction and sum
        mark (int): index of the maximum value
        
    :returns:
        int: index of the maximum value
    """
    maxind = mark
    for i in range(mark+1,len(data)):
        if data[i][1]>data[maxind][1]:
            maxind = i
    return maxind

def selection(data: dict) -> dict:
    """
    Selection Sort
    :args:
        data (dict): dictionary of coordinates,direction and sum
        
    :returns:
        dict: dictionary of coordinates,direction and sum
    """
    for i in range(len(data)):
        mark = i
        maxind = findmax(data,mark)
        data[mark],data[maxind] = data[maxind],data[mark]
    return data


