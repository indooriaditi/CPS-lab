"""
CSCI-603 Lab 7: LinkedHashTable

Implementing a implement a linked hash set
that remembers the order of insertion.

author: ADITI INDOORI
"""

import collections
from typing import Any
from set import SetType


class ChainNode:
    __slots__ = 'obj', 'prev', 'fwd', 'next'

    def __init__(self, obj: Any, prev: 'ChainNode' = None,
                 next: 'ChainNode' = None, fwd: 'ChainNode' = None):
        """
        Create a new node.
        :param obj: the item to stored in the node
        :param prev: the previous node inserted in the set (ordering link)
        :param next: the next node inserted in the set (ordering link)
        :param fwd: the next node in the bucket's chain (hash table link)
        :return: None
        """
        self.obj = obj
        self.prev = prev
        self.fwd = fwd
        self.next = next

    def __repr__(self) -> str:
        """
        Return a string with the string representation of the object
        in this node and the object of the node to which it is linked by
        the fwd link.
        This function should not be called for a circular
        list. The format of the string is as follows:

            {obj1} -> {obj2} -> {obj3}
        """
        if self.next is not None:
            return "{" + repr(self.obj) + "}" + "->" + repr(self.next)
        else:
            return "{" + repr(self.obj) + "}"

    def __str__(self) -> str:
        """
        Return the string representation of the object in this node.
        """
        return str(self.obj)


class LinkedHashSet(SetType, collections.abc.Iterable):
    __slots__ = '_initial_num_buckets', '_load_limit', \
                '_hash_function', '_table', '_front', '_back'

    def __init__(self, initial_num_buckets: int = 100, load_limit: float = 0.75,
                 hash_function=hash, front: 'ChainNode' = None, back: 'ChainNode' = None):
        """
        Create a new empty set.
        :param initial_num_buckets: starting number_of_buckets
        :param load_limit: specifies a range outside which the table is too
        full or empty.
        When load_factor (ratio of size to number_of_buckets) reaches load_limit, the
        number_of_buckets is doubled. When it gets under (1-load_limit),
        the number_of_buckets is cut in half.
        :param hash_function: The hash function to use in this hash table.
        By default, it will the built-in hash function.
        :return: None
        """
        super().__init__()
        if initial_num_buckets < 10:
            self._initial_num_buckets = 10
        self._initial_num_buckets = initial_num_buckets
        self._load_limit = load_limit
        self._hash_function = hash_function
        self._table = [None] * initial_num_buckets
        self._front = front
        self._back = back

    def __len__(self) -> int:
        """
        Return the number of elements in this set.
        :return: the number of elements in the set.
        """
        return self.size

    def __str__(self) -> str:
        """
        Return a string representation of the objects added to
        this set sorted by insertion order.
        The string will contain all the objects separated by comma
        and enclosed between curly braces.
        """
        node = self._front
        result = "{" + str(node.obj)
        while node.next is not self._back.next:
            node = node.next
            result += ", " + str(node.obj)
        result += "}"
        return result

    def __repr__(self) -> str:
        """
        Return a string with the content of the hash table
        and information about the hash table such as the
        table's capacity, size, current load factor and load limit.
        """
        capacity = self._initial_num_buckets
        size = self.__len__()
        load_factor = size / capacity
        load_limit = self._load_limit
        rep = "String generated\n----------------\n"
        rep += f"Capacity: {capacity}, Size: {size}, " \
               f"Load Factor: {load_factor}, Load Limit: {load_limit}\n\n"
        rep += "\tHash table\n\t----------\n"
        for i in range(len(self._table)):
            rep += f"\t{i}: "
            if self._table[i] is not None:
                node = self._table[i]
                rep += f"'{node.obj}'"
                while node.fwd is not None:
                    node = node.fwd
                    rep += f" -> '{node.obj}'"
                else:
                    rep += f" -> None"
            else:
                rep += "None"
            rep += "\n"
        return rep

    def __iter__(self) -> None:
        """
        Build an iterator.
        :return: an iterator for the current elements in the set
        """
        node = self._front
        while node is not self._back:
            yield node.obj
            node = node.next
        yield self._back

    def find_index(self, obj: Any, size: int) -> int:
        """
        Create a new empty set.
        :param obj: the object whose index to find
        :param size: the number of buckets
        :return: int index value
        """
        return self._hash_function(obj) % size

    def contains(self, obj: Any) -> bool:
        """
        Is the given obj in the set?
        :return: True if obj or its equivalent has been added to this set
        """
        node = self._table[self.find_index(obj, self._initial_num_buckets)]
        if node is not None:
            if node.obj == obj:
                return True
            else:
                while node.fwd is not None:
                    node = node.fwd
                    if node.obj == obj:
                        return True
        return False

    def rehash(self) -> None:
        """
        Sizes the table up or down based on the load_factor and
        rehashes the values of the old table in the newly resized table
        """
        load_factor = self.size / self._initial_num_buckets
        if load_factor >= self._load_limit:
            num_of_buckets = self._initial_num_buckets * 2
        elif load_factor < (1 - self._load_limit):
            num_of_buckets = self._initial_num_buckets // 2

        new_table = LinkedHashSet(num_of_buckets)

        # iterate over old table and add all the elements to new table
        for obj in self:
            new_table.add(obj)

        # copy new table back to the old table and reset old parameters to new
        self._table = new_table._table
        self._initial_num_buckets = num_of_buckets
        self._front = new_table._front
        self._back = new_table._back

    def add(self, obj: Any) -> bool:
        """
        Insert a new object into the hash table and remember when it was added
        relative to other calls to this method. However, if the object is
        added multiple times, the hash table is left unchanged, including the
        fact that this object's location in the insertion order does not change.
        Double the size of the table if its load_factor exceeds the load_limit.
        :param: obj - the object to add
        :return: True if obj has been added to this set
        """
        location = self.find_index(obj, self._initial_num_buckets)
        node = self._table[location]
        new_node = ChainNode(obj)

        load_factor = self.size / self._initial_num_buckets

        # Check if the load factor exceeds the load_limit
        if load_factor >= self._load_limit:
            self.rehash()
            location = self.find_index(obj, self._initial_num_buckets)
            node = self._table[location]

        if not self.contains(obj):
            if node is None:
                self._table[location] = new_node
                if self._front is None:
                    self._front = new_node
                if self._back is not None:
                    node2 = self._back
                    node2.next = new_node
                    new_node.prev = node2
                self._back = new_node  # back points to new node
            else:
                while node.fwd is not None:
                    node = node.fwd
                node.fwd = new_node
                if self._back is not None:  # can remove if
                    node2 = self._back
                    node2.next = new_node
                    new_node.prev = node2
                self._back = new_node  # back points to newly added node
            self.size += 1
            return True
        else:
            return False

    def remove(self, obj: Any) -> bool:
        """
        Remove an object from the hash table (and from the insertion order).
        Resize the table if its load_factor has dropped below (1-load_limit).
        :param obj: the value to remove; assumes hashing and equality work
        :return: True iff the obj has been remove from this set
        """
        location = self.find_index(obj, self._initial_num_buckets)
        node = self._table[location]

        if self.contains(obj):
            # removing directly from the hashtable
            if obj == node.obj:
                next_node = node.next
                prev_node = node.prev

                # removing last element
                if next_node is None:
                    prev_node.next = None
                    self._back = prev_node

                # removing first element
                elif prev_node is None:
                    next_node.prev = None
                    self._front = next_node

                # middle element
                else:
                    prev_node.next = node.next
                    next_node.prev = node.prev

                # if it has more elements in a chain
                if node.fwd is not None:
                    self._table[location] = node.fwd
                else:
                    self._table[location] = None

                node.fwd = None
                node.next = None

            # removing from chain
            else:
                temp = None
                # to find the object
                while node.fwd is not None:
                    if str(node.fwd) == obj:
                        temp = node
                    node = node.fwd
                    if node.obj == obj:
                        break
                next_node = node.next
                prev_node = node.prev

                # removing last element
                if next_node is None:
                    prev_node.next = None
                    self._back = prev_node

                # removing a middle element
                else:
                    prev_node.next = node.next
                    next_node.prev = node.prev

                # if it has more elements in the chain
                if node.fwd is not None:
                    temp.fwd = node.fwd
                else:
                    temp.fwd = None

                node.prev = None
                node.fwd = None
                node.next = None

            self.size -= 1

            load_factor = self.size / self._initial_num_buckets
            if load_factor < (1 - self._load_limit):
                self.rehash()
            return True
        else:
            return False
