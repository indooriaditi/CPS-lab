"""
file: tests.py
description: Verify the LinkedHashSet class implementation
"""

__author__ = "Aditi Indoori"

from linkedhashset import LinkedHashSet


def print_set(a_set):
    for word in a_set:  # uses the iter method
        print(word, end=" ")
    print()


def test0():
    table = LinkedHashSet(100)
    table.add("to")
    table.add("do")
    table.add("is")
    table.add("to")
    table.add("be")

    print_set(table)

    print("'to' in table?", table.contains("to"))
    table.remove("to")
    print("'to' in table?", table.contains("to"))

    print_set(table)


def test1():
    table = LinkedHashSet(5)
    table.add("batman")
    table.add("has")
    table.add("lots")
    table.add("of")
    table.add("gizmos")
    table.add("on")
    table.add("his")
    table.add("belt")

    print_set(table)

    print("'on' in table?", table.contains("on"))
    table.remove("on")
    print("'on' in table?", table.contains("on"))
    print(repr(table))


def test2():
    table = LinkedHashSet(10)
    table.add("a")
    table.add("a")
    table.add("a")
    table.add("b")
    table.add("b")
    table.add("c")
    table.add("a")
    table.add("a")
    table.add("c")
    table.add("d")

    print_set(table)

    print("'z' in table?", table.contains("z"))
    print("Removing 'a'...")
    table.remove("a")
    print("'a' in table?", table.contains("a"))

    print(table)


def test3():
    table = LinkedHashSet(10)
    table.add("a")
    table.add("b")
    table.add("c")
    table.add("d")
    table.add("e")
    table.add("f")
    table.add("g")
    table.add("h")
    table.add("i")
    table.add("j")

    print(repr(table))


def test4():
    table = LinkedHashSet(10)
    table.add("a")
    table.add("b")
    table.add("c")
    table.add("d")
    table.add("e")
    print(repr(table))

    table.remove("a")
    table.remove("b")
    table.remove("c")
    print("After removing some elements, table is resized and values are rehashed")
    print(repr(table))

    table.add("k")
    table.add("l")
    table.add("m")
    table.add("n")
    table.add("x")
    table.add("y")
    table.add("z")
    print("After adding some more elements, table is resized and values are rehashed")
    print(repr(table))


if __name__ == '__main__':
    print("-------------Test 0-------------")
    test0()
    print("\n-------------Test 1-------------")
    test1()
    print("\n-------------Test 2-------------")
    test2()
    print("\n-------------Test 3-------------")
    test3()
    print("\n-------------Test 4-------------")
    test4()
