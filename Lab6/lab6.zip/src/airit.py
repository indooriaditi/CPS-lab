"""
CSCI-603 Lab 6: AiRIT

Implementing a simulation of an airplane AiRIT
dedicated to getting students to their 
Spring Break destination.

author: ADITI INDOORI
"""

import sys
import os
from stack import Stack
from queue_1 import Queue
from aircraft import Aircraft
from gate import Gate


def read_file(file_name: str) -> list:
    """
    Reads passengers from a file and stores it as 
    a list of lists.
    :args:
        file_name (str): name of the file.
    :returns:
        list: list of lists representing the passengers.
    """
    list_of_passengers = list()
    with open(file_name) as f:
        for line in f:
            list_of_passengers.append(line.strip().split(','))
    return list_of_passengers


def validate(val: int, prompt: str) -> int:
    """
    validates user input for gate_capacity
    and aircraft_capacity.
    :args:
        val (int): value of gate_capacity or aircraft_capacity given by user
        prompt (str): prompt to display to user.
    :returns:
        int: value of gate_capacity or aircraft_capacity given by user
    """
    try:
        val = int(input(prompt))
        while val <= 0:
            print("Please enter a positive integer value")
            val = int(input(prompt))
    except ValueError:
        print("Please enter a valid integer value")
        val = int(input(prompt))
        while val <= 0:
            print("Please enter a positive integer value")
            val = int(input(prompt))
    return val


def run_simulation() -> None:
    """
    Handles the logic for adding passengers to the gate
    and then to respective boarding zones
    followed by boarding them into the plane and
    unloading them from the plane.
    :return: None
    """
    temp = 0
    index = 0
    no_of_flights = 0
    list_of_queues = [Queue(), Queue(), Queue(), Queue()]
    aircraft_True = Stack()
    aircraft_False = Stack()
    list_of_stacks = [aircraft_False, aircraft_True]

    if len(sys.argv) == 1:
        print('Usage: python3 airit.py {filename}')
        sys.exit()
    elif not os.path.exists('../data/' + sys.argv[1]):
        print('File not found:', sys.argv[1])
        sys.exit()

    file_name = '../data/' + sys.argv[1]
    list_of_passengers = read_file(file_name)
    no_of_passengers = len(list_of_passengers)
    gate_capacity = validate(temp, "Gate capacity: ")
    aircraft_capacity = validate(temp, "Aircraft capacity: ")

    print('Reading passenger data from', sys.argv[1])
    print('Beginning simulation...')

    # loading passengers into the gates and queues
    while index < len(list_of_passengers):
        passengers_at_gate = 0
        remaining_gate_capacity = gate_capacity
        total_passengers_flying = 0
        print('Passengers are lining up at the gate...')
        gate = Gate()
        passengers_at_gate = gate.fill_the_gate(index, passengers_at_gate, remaining_gate_capacity,
                                                list_of_passengers, list_of_queues)

        if len(list_of_passengers) - index >= gate_capacity:
            print('The gate is full; remaining passengers must wait.')
        else:
            print('The last passenger is in line!')

        # adding passengers into the aircraft
        while remaining_gate_capacity > 0 and (index + total_passengers_flying < len(list_of_passengers)):
            passengers_in_plane = 0
            print('Passengers are boarding the aircraft...')
            aircraft = Aircraft()
            passengers_in_plane = aircraft.add_to_aircraft(
                list_of_queues, passengers_in_plane, aircraft_capacity, aircraft_True, aircraft_False)
            remaining_gate_capacity -= passengers_in_plane
            passengers_at_gate -= passengers_in_plane
            total_passengers_flying += passengers_in_plane
            if (aircraft_capacity-passengers_in_plane) == 0:
                print(
                    'The aircraft is full.\nReady for taking off ...\nThe aircraft has landed.'
                    '\nPassengers are disembarking...')
                no_of_flights += 1
            elif (aircraft_capacity-passengers_in_plane) != 0 and passengers_at_gate==0:
                print(
                    'There are no more passengers at the gate.\nReady for taking off ...'
                    '\nThe aircraft has landed.\nPassengers are disembarking...')
                no_of_flights += 1
            aircraft.disembark_passengers(list_of_stacks)

        index += gate_capacity
    print('Simulation complete. Statistics: ' + str(no_of_flights) +
          ' flights, ' + str(no_of_passengers) + ' passengers are at their destination')


def main() -> None:
    """
    The main loop responsible for running the AiRIT's simulation.
    :return: None
    """
    run_simulation()


if __name__ == '__main__':
    main()
