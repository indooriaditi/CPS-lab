class Aircraft:
    def add_to_aircraft(self, list_of_queues: list, passengers_in_plane: int, aircraft_capacity: int,
                        aircraft_True: object, aircraft_False: object) -> int:
        """
        loads passengers into the aircraft.
        :args:
            list_of_queues (list): list of the boarding zones
            passengers_in_plane (int): number of passengers loaded in the aircraft
            aircraft_capacity (int): number of passengers that can be loaded in the aircraft
            aircraft_True (object): a stack object representing passegers in the aircraft with a carry on
            aircraft_False (object): a stack object representing passegers in the aircraft without a carry on
        :returns:
            int: number of passengers in the aircraft
        """
        for i in reversed(list_of_queues):
            if not i.is_empty():
                while not i.is_empty():
                    name = i.peek()[0]
                    ticket = i.peek()[1]
                    carry_on = i.peek()[2]
                    if eval(carry_on) and (passengers_in_plane < aircraft_capacity):
                        passengers_in_plane += 1
                        aircraft_True.push(i.peek())
                        print('\t' + name + ', ticket: ' +
                              ticket + ', carry_on: ' + carry_on)
                        i.dequeue()
                    elif (not eval(carry_on)) and (passengers_in_plane < aircraft_capacity):
                        passengers_in_plane += 1
                        aircraft_False.push(i.peek())
                        print('\t' + name + ', ticket: ' +
                              ticket + ', carry_on: ' + carry_on)
                        i.dequeue()
                    else:
                        break
        return passengers_in_plane

    def disembark_passengers(self, list_of_stacks: list) -> None:
        """
        unloads passengers from the aircraft.
        :args:
            list_of_stacks (list): list of the stacks representing passegers 
                                in the aircraft with and without a carry on
        :returns: None
        """
        for i in list_of_stacks:
            if not i.is_empty():
                while not i.is_empty():
                    name = i.peek()[0]
                    ticket = i.peek()[1]
                    carry_on = i.peek()[2]
                    print('\t' + name + ', ticket: ' +
                          ticket + ', carry_on: ' + carry_on)
                    i.pop()
