from passenger import Passenger


class Gate:
    def fill_the_gate(self, index: int, passengers_at_gate:int, remaining_gate_capacity: int,
                      list_of_passengers: list, list_of_queues: list) -> int:
        """
        Fills passengers in the gate and queues.
        :args:
            index (int): index of the list of passengers
            passengers_at_gate (int): number of passengers at the gate
            remaining_gate_capacity (int): updated gate capacity after loading passengers into the aircraft
            list_of_passengers (list): list of lists of the passengers
            list_of_queues (list): list of the boarding zones
        :returns: int: number of passengers at the gate
        """
        # adding passengers at the gate into boarding zones (queues)
        for i in range(index, min(index + remaining_gate_capacity, len(list_of_passengers))):
            passengers_at_gate +=1
            name = list_of_passengers[i][0]
            ticket = list_of_passengers[i][1]
            carry_on = list_of_passengers[i][2]
            passenger = Passenger(name, ticket, carry_on)
            print(passenger)
            passenger.add_to_queue(list_of_queues)
        return passengers_at_gate
