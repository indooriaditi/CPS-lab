class Passenger:
    __slots__ = ("_full_name", "_ticket_number", "_carry_on")

    def __init__(self, full_name: str, ticket_number: str, carry_on: str) -> None:
        """ Create a new passenger."""
        self._full_name = full_name
        self._ticket_number = ticket_number
        self._carry_on = carry_on

    def __str__(self) -> str:
        """ print the passenger details."""
        return "\t" + self._full_name + ', ticket: ' + self._ticket_number \
               + ', carry_on: ' + self._carry_on

    def add_to_queue(self, list_of_queues) -> None:
        """ enqueue each passenger to the respective boarding zone."""
        list_of_queues[int(self._ticket_number[0]) - 1].enqueue([self._full_name,
                                                                 self._ticket_number, self._carry_on])
