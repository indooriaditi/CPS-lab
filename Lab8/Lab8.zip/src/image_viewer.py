import sys
import os
from math import *
from tkinter import *
from quadtree import QuadTree


class ImageViewer:
    __slots__ = "file_name"

    def __init__(self, file_name):
        """
        Initialize the filename.
        """
        self.file_name = file_name

    def view_image(self, compressed: bool) -> None:
        """
        Displays the image using Tkinter based on the compression type.
        :param compressed (bool): Indicates whether the image is compressed or uncompressed.
        :return: None
        """
        qt = QuadTree()
        window = Tk()
        if compressed:
            dimension, array = qt.compressed_tree(self.file_name)
            print('Quadtree: ' + str(qt))
            photo_image = PhotoImage(width=dimension, height=dimension)
            canvas = Canvas(window, width=dimension, height=dimension)
            for y in range(dimension):
                for x in range(dimension):
                    grayscale_value = array[y][x]
                    color = "#{:02x}{:02x}{:02x}".format(
                        grayscale_value, grayscale_value, grayscale_value)
                    photo_image.put(color, to=(x, y))
            canvas.create_image(0, 0, anchor=NW, image=photo_image)
            canvas.pack()
            window.mainloop()
        else:
            grayscale_values = qt.uncompressed_tree(self.file_name)
            dimension = int(sqrt(len(grayscale_values)))
            photo_image = PhotoImage(width=dimension, height=dimension)
            canvas = Canvas(window, width=dimension, height=dimension)
            for y in range(dimension):
                for x in range(dimension):
                    grayscale_value = grayscale_values[y*dimension+x]
                    color = "#{:02x}{:02x}{:02x}".format(
                        grayscale_value, grayscale_value, grayscale_value)
                    photo_image.put(color, to=(x, y))
            canvas.create_image(0, 0, anchor=NW, image=photo_image)
            canvas.pack()
            window.mainloop()


def validate_file():
    """
    Validates the command-line arguments and file existence, 
    then initializes and displays the image.
    """
    qt = QuadTree()
    compressed = False
    if len(sys.argv) != 3 and len(sys.argv) != 2:
        print("Usage: python image_viewer.py [-c] <filename>")
        sys.exit()
    if len(sys.argv) == 2:
        if not os.path.exists('../images/uncompressed/' + sys.argv[1]):
            print('File not found:', sys.argv[1])
            sys.exit()
        else:
            file_path = '../images/uncompressed/' + sys.argv[1]
            img = ImageViewer(file_path)
            img.view_image(compressed)
    elif len(sys.argv) == 3:
        if not os.path.exists('../images/compressed/' + sys.argv[2]):
            print('File not found:', sys.argv[2])
            sys.exit()
        else:
            compressed = True
            file_path = '../images/compressed/' + sys.argv[2]
            print("Uncompressing: " + sys.argv[2])
            img = ImageViewer(file_path)
            img.view_image(compressed)


def main():
    validate_file()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(e)
