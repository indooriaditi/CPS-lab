from qtnode import QTNode
from math import *
from qtexception import QTException
import sys


class QuadTree:
    __slots__ = "root"

    def __init__(self):
        """
        Initialize the root of the tree.
        """
        self.root = None

    def create_tree(self, values: list) -> QTNode:
        """
        create a tree from the list of values fetched from file.
        :param values: list of values fetched from file.
        :return: the node of the tree.
        """
        pixel_value = values.pop(0)
        if pixel_value != -1:
            if not (0 <= pixel_value <= 255):
                raise QTException("Pixel value is outside the valid range.")
            return QTNode(pixel_value)
        qt_node = QTNode(pixel_value)
        qt_node._ul = self.create_tree(values)
        qt_node._ur = self.create_tree(values)
        qt_node._ll = self.create_tree(values)
        qt_node._lr = self.create_tree(values)
        return qt_node

    def tree_to_array(self, tree: QTNode, x: int, y: int, size: int, result: list) -> list:
        """
        converts the tree to a 2d aray.
        :param tree: The tree.
        :param x: x coordinate.
        :param y: y coordinate.
        :param size: dimension of the image.
        :param result: 2d array.
        :return: the tree converted to a 2d array.
        """
        if tree._value != -1:
            if size == 1:
                result[x][y] = tree._value
            else:
                for i in range(x, size + x):
                    for j in range(y, size + y):
                        result[i][j] = tree._value
        else:
            self.tree_to_array(tree._ul, x, y, size//2, result)
            self.tree_to_array(tree._ur, x, y+size//2, size//2, result)
            self.tree_to_array(tree._ll, x+size//2, y, size//2, result)
            self.tree_to_array(tree._lr, x+size//2, y+size//2, size//2, result)
        return result

    def compressed_tree(self, file_name: str):
        """
        Reads a compressed tree from a file and returns the dimension of the image 
        and list of the pixel values.
        :param file_name (str): The name of the file containing the compressed tree.
        :return: the dimension of the image and list of the pixel values.
        """
        grayscale_values = []
        with open(file_name) as f:
            size = int(f.readline().strip())
            check_square = log2(sqrt(size))
            if not check_square.is_integer():
                raise QTException("Image size is not square (a power of two).")
            for line in f:
                value = line.strip()
                if value != "-1" and not value.isnumeric():
                    raise QTException(
                        "Non-integer value encountered for a pixel value.")
                grayscale_values.append(int(value))
        self.root = self.create_tree(grayscale_values)
        array_size = int(sqrt(size))
        result = [[None]*array_size for i in range(array_size)]
        array = self.tree_to_array(self.root, 0, 0, array_size, result)
        return array_size, array

    def uncompressed_tree(self, file_name: str) -> list:
        """
        Reads an uncompressed tree from a file and returns a list of the pixel values.
        :param file_name (str): The name of the file containing the uncompressed tree.
        :return: The list of pixel values.
        """
        grayscale_values = []
        with open(file_name) as f:
            for line in f:
                grayscale_values.append(int(line.strip()))
        return grayscale_values

    def preorder(self, node: QTNode) -> str:
        """
        Performs a preorder traversal of the quadtree -> ul,ur,ll,lr.
        :param node (QTNode): The current node in the traversal.
        :return: The string representation of the quadtree.
        """
        if node is None:
            return ''
        else:
            return str(node.get_value()) + ' ' + \
                self.preorder(node.get_upper_left()) + \
                self.preorder(node.get_upper_right()) + \
                self.preorder(node.get_lower_left()) + \
                self.preorder(node.get_lower_right())

    def __str__(self) -> str:
        """
        Return a string representation of the tree.
        :return: string
        """
        return self.preorder(self.root)
