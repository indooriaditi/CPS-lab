"""
CSCI-603 Lab 4: Wordle

Implementing a plain-text user interface (PTUI),
i.e., a console window, version of the game Wordle.

author: ADITI INDOORI
"""

from dataclasses import dataclass
import random
import sys


@dataclass
class Wordle:
    """
    The Wordle game representation.
    """
    answer_word: str
    guess_word: str
    output_word: str
    legal_words: list
    played_words: list
    letters_used: set
    attempts_count: int
    previous_attempts: list
    game_over: bool

    def __init__(self):
        """
        Initializes a new instance of the game.
        """
        self.legal_words = self.readFile("wordle.txt")
        if len(sys.argv) == 2:
            self.answer_word = sys.argv[1].upper()
        elif len(sys.argv) == 1:
            self.answer_word = self.getWord()
        else:
            print("Usage: wordle [1st-secret-word]")
            sys.exit()
        self.attempts_count = 0
        self.letters_used = set()
        self.previous_attempts = []
        self.game_over = False

    def help(self) -> None:
        """
        Displays the help commands.
        """
        print("commands:")
        print("\tnew: Start a new game")
        print("\tguess <word>: Make a guess")
        print("\tcheat: Show the secret word")
        print("\thelp: This help message")
        print("\tquit: End the program")

    def readFile(self, fileName: str) -> list:
        """
        Reads legal words from a file and stores it in a list.
        :args:
            fileName (str): name of the file i.e. the absolute path.
        :returns:
            list: list of legal words.
        """
        words = list()
        with open(fileName) as f:
            for line in f:
                words.append(line.strip('\n'))
        return words

    def getWord(self) -> str:
        """
        Selects a random word from the list.
        :returns:
            str: random word.
        """
        return random.choice(self.legal_words)

    def guess(self, command: str) -> None:
        """
        Logic to handle the guessed word
        and move through the states of the game.
        :args:
            command: the guess command i.e. the guess word.
        """
        try:
            word_guessed = command.split()[1].upper()
            if (len(word_guessed) == 5) and (word_guessed in self.legal_words):
                self.attempts_count += 1
                self.guess_word = word_guessed
                self.output_word = self.playWordle(self.answer_word, self.guess_word)
                self.previous_attempts.append([self.guess_word, self.output_word])
                for i in self.guess_word:
                    self.letters_used.add(i)
                print("\nNum of guesses: ", self.attempts_count, " of 6\n")
                for i in self.previous_attempts:
                    print(i[0])
                    print(i[1])
                    print("")
                print("Letters used: ", self.letters_used)
                if self.guess_word == self.answer_word:
                    self.game_over = True
                    print("\nYou won!!")
                if self.attempts_count >= 6:
                    self.game_over = True
                    print("\nYou lost!!")
                    print("The secret word was ", self.answer_word)
            else:
                print("Illegal word")
        except IndexError:
            print("invalid command")

    def playWordle(self, ans: str, guess: str) -> str:
        """
        Main logic of wordle game.
        :args:
            ans: the answer word.
            guess: the guess word.
        :returns:
            str: the output word displaying the symbols.
        """
        a_count = dict()
        output = ""
        output2 = ""
        for i in ans:
            if i in a_count:
                a_count[i] += 1
            else:
                a_count[i] = 1
        for i in range(len(guess)):
            temp = guess[i]
            for j in range(len(ans)):
                if j == i and ans[j] == guess[i] and a_count[ans[j]] > 0:
                    temp = "^"
                    a_count[ans[j]] -= 1
                    break
            output += temp
        for i in range(len(output)):
            temp = " "
            for j in range(len(ans)):
                if output[i] == "^":
                    temp = "^"
                    break
                elif ans[j] == output[i] and j != i and a_count[ans[j]] > 0:
                    temp = "*"
                    a_count[ans[j]] -= 1
                    break
            output2 += temp
        return output2

    def getInput(self) -> None:
        """
        Logic to handle the user inputs
        and call the respective function.
        """
        while not self.game_over:
            input_command = input("\n> ")
            if input_command == "new":
                self.__init__()
                self.answer_word = self.getWord()
                self.getInput()
            if input_command.split()[0] == "guess":
                while self.attempts_count < 6:
                    self.guess(input_command)
                    self.getInput()
            if input_command == "cheat":
                print("")
                print(self.answer_word)
                self.getInput()
            if input_command == "help":
                print("")
                self.help()
                self.getInput()
            if input_command == "quit":
                print("\nBye!")
                sys.exit()
            else:
                print("\nUnknown command: ", input_command)
                self.help()
                self.getInput()

        while self.game_over:
            input_command = input("\n> ")
            if input_command == "new":
                self.__init__()
                self.answer_word = self.getWord()
                self.getInput()
            elif input_command == "help":
                print("")
                self.help()
            elif input_command == "quit":
                print("\nBye!")
                sys.exit()
            elif input_command != "cheat" and input_command.split()[0] != "guess":
                print("\nUnknown command: ", input_command)
                self.help()

    def main(self) -> None:
        """
        The main method that starts the wordle game.
        """
        print("Welcome to wordle App!")
        self.help()
        self.getInput()


if __name__ == "__main__":
    """
    Creating an instance of the class
    and calling the main method.
    """
    wordle_obj = Wordle()
    wordle_obj.main()
